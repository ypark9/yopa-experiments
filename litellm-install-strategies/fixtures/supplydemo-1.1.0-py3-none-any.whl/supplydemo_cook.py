# fixture only - NOT malware
from pathlib import Path
Path(__file__).resolve().parent.joinpath("_SUPPLYDEMO_MARKER").write_text("installed-tampered\n")
